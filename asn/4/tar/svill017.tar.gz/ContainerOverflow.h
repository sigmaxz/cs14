// Course: CS 14 Spring 2012
// 
// First Name: Samuel
// Last Name: Villarreal
// UCR Username: svill017
// UCR Email Address: svill017@ucr.edu
// 
// Lecture Section: 001
// Lab Section: 021
// TA: Krystof Litomisky
// 
// Assignment: assignment 4
// 
// I hereby certify that the code in this file
// is ENTIRELY my own original work.
// 
// ===========================================================================
#ifndef CONTAINEROVERFLOW_H
#define CONTAINEROVERFLOW_H

#include <iostream>
using namespace std;

class ContainerOverflow
{
public:
  string err;
  ContainerOverflow(string s)
  :err(s) {}
  std::string what() const
  {
    return err;
  }
  
};

#endif
