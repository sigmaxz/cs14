#ifndef LIST_NODE_H
#define LIST_NODE_H

class ListNode
{
public:
  std::string word;
  ListNode* next;
};

#endif
