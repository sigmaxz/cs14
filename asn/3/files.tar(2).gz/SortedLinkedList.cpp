// Course: CS 14 Spring 2012
// 
// First Name: John
// Last Name: Smith
// UCR Username: jsmit003
// UCR Email Address: jsmit003@student.ucr.edu
// 
// Lecture Section: 001
// Lab Section: 021
// TA: Krystof Litomisky
// 
// Assignment: assignment 3
// 
// I hereby certify that the code in this file
// is ENTIRELY my own original work.
// 
// ===========================================================================

#include "Timer.h"
#include "SortedLinkedList.h"

using namespace std;

SortedLinkedList::SortedLinkedList() : head(NULL) {}

SortedLinkedList::SortedLinkedList(const SortedLinkedList & source)
: SortedList(), head(NULL)
{
  if(source.head == NULL) return;
  head = new ListNode(source.head->word);
  ListNode * thisNode = head;
  ListNode * sourceNode = source.head->next;
  while(sourceNode != NULL)
  {
    thisNode->next = new ListNode(sourceNode->word);
    thisNode = thisNode->next;
    sourceNode = sourceNode->next;
  }
}

SortedLinkedList::~SortedLinkedList() {destroy_list();}

SortedLinkedList & SortedLinkedList::operator =(const SortedLinkedList & rhs)
{
  if(this == &rhs) return *this;
  destroy_list();
  create_list(rhs);
  return *this;
}

void SortedLinkedList::insert(const string & word)
{
  exit(1); // *** REPLACE WITH YOUR IMPLEMENTATION ***
}

bool SortedLinkedList::find(const string & word) const
{
  exit(1); // *** REPLACE WITH YOUR IMPLEMENTATION ***
}

void SortedLinkedList::remove(const string & word)
{
  exit(1); // *** REPLACE WITH YOUR IMPLEMENTATION ***
}

void SortedLinkedList::create_list(const SortedLinkedList & source)
{
  if(source.head == NULL) return;
  head = new ListNode(source.head->word);
  ListNode * current = head->next;
  for(ListNode * p = source.head->next; p != NULL; p = p->next)
  {current = new ListNode(p->word); current = current->next;}
}

void SortedLinkedList::destroy_list()
{
  while(head!= NULL)
  {
    ListNode * current = head;
    head = head->next;
    delete current;
  }
}
